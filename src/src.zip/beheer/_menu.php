			<div class="c_box">
				<div class="heading"><div class="icon box"></div>Menu</div>
				<div class="inner">
					<div class="nav_link static"><div class="icon building"></div><strong>Algemeen</strong></div>
					<a href="/beheer/index"><div class="nav_link static" style="margin-left: 5px;"><div class="icon house"></div>Homepage</div></a>
					<a href="/beheer/statistieken"><div class="nav_link static" style="margin-left: 5px;"><div class="icon chart_bar"></div>Statistieken</div></a>
					<a href="/beheer/parsetijd"><div class="nav_link static" style="margin-left: 5px;"><div class="icon clock_red"></div>PHP Parse-tijd</div></a>
					<br/>
					<div class="nav_link static"><div class="icon group"></div><strong>Gebruikers</strong></div>
					<a href="/beheer/ledenlijst"><div class="nav_link static" style="margin-left: 5px;"><div class="icon user_green"></div>Ledenlijst</div></a>
					<a href="/beheer/gebruiker_bewerken"><div class="nav_link static" style="margin-left: 5px;"><div class="icon user_edit"></div>Gebruiker bewerken</div></a>
					<a href="/beheer/punten"><div class="nav_link static" style="margin-left: 5px;"><div class="icon coins"></div>Punten beheren</div></a>
					<a href="/beheer/berichten"><div class="nav_link static" style="margin-left: 5px;"><div class="icon email"></div>Priv&eacute;berichten</div></a>
					<a href="/beheer/team"><div class="nav_link static" style="margin-left: 5px;"><div class="icon user_suit"></div>Team beheren</div></a>
					<a href="/beheer/warnen"><div class="nav_link static" style="margin-left: 5px;"><div class="icon user_red"></div>Warnen</div></a>
					<br/>
					<div class="nav_link static"><div class="icon comments"></div><strong>Forum</strong></div>
					<a href="/beheer/fora"><div class="nav_link static" style="margin-left: 5px;"><div class="icon package"></div>Fora beheren</div></a>
					<a href="/beheer/posts"><div class="nav_link static" style="margin-left: 5px;"><div class="icon page"></div>Forum posts</div></a>
					<br/>
					<div class="nav_link static"><div class="icon help"></div><strong>Support-Center</strong></div>
					<a href="/beheer/tickets"><div class="nav_link static" style="margin-left: 5px;"><div class="icon note"></div>Ticket systeem</div></a>
					<a href="/beheer/reports"><div class="nav_link static" style="margin-left: 5px;"><div class="icon error"></div>Forum reports</div></a>
				</div>
			</div>
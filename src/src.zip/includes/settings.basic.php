<?php
$glb_settings = Array();

$glb_settings['cookie_us'] = 'glybe_aseuses_24_07_cookie';
?>
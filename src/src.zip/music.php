<?php
include'includes/inc.bootstrap.php';
$page = Array('title' => 'Music', 'class' => 'music_app');
include'content/header.php';
?>
	<div class="player_bar">
		<div class="btn goback"></div>
		<div class="btn pause"></div>
		<div class="btn play"></div>
		<div class="btn goforward"></div>
	</div>
	<div class="search_bar">
		
	</div>
	<div class="app_content">
		<div class="artists">
			<br/>
			<div class="artist b">Megan Nicole</div>
			<div class="artist">Bas Milius</div>
			<div class="artist b">Tiffany Alvord</div>
			<div class="artist">Jesse Reitsma</div>
		</div>
		<div class="songs">
			<div class="nav_bar">
				
			</div>
			<div class="cover_flow">
				
			</div>
		</div>
	</div>
	<div class="bottom_bar">
		
	</div>
</body>
</html>
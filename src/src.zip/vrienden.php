<?php
ob_start();
header('Location: /vrienden/index');
?>